const request = require('supertest');
const app = require('../app');
const DataService = require('../services/dataService');

// Mock DataService
jest.mock('../services/dataService');

describe('API Endpoints', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    // Mock successful data loading
    DataService.prototype.loadGraph = jest.fn().mockResolvedValue({
      nodes: [['佛山西', 'C4781', '06:00'], ['肇庆', 'C4781', '07:07']],
      edges: [{ from: ['佛山西', 'C4781', '06:00'], to: ['肇庆', 'C4781', '07:07'], weight: 67, type: 'travel' }]
    });

    DataService.prototype.loadSchedule = jest.fn().mockResolvedValue({
      train: [{ id: 'C4781', is_fast: false, directionality: [1, 0, 0, 0] }]
    });

    DataService.prototype.buildAdjacencyList = jest.fn().mockReturnValue({
      0: [{ to: 1, type: 'travel', duration: 67 }],
      1: []
    });

    DataService.prototype.extractTrainInfo = jest.fn().mockReturnValue({
      'C4781': { is_fast: false, directionality: [1, 0, 0, 0] }
    });

    DataService.prototype.extractDirectionalityMap = jest.fn().mockReturnValue({
      'C4781': [1, 0, 0, 0]
    });
  });

  describe('GET /', () => {
    test('should return API information', async () => {
      const response = await request(app)
        .get('/')
        .expect(200);

      expect(response.body.message).toBe('Metro Plan Backend API');
      expect(response.body.version).toBe('1.0.0');
      expect(response.body.endpoints).toBeDefined();
    });
  });

  describe('GET /health', () => {
    test('should return health status', async () => {
      const response = await request(app)
        .get('/health')
        .expect(200);

      expect(response.body.status).toBe('OK');
      expect(response.body.service).toBe('metro-plan-backend');
      expect(response.body.timestamp).toBeDefined();
    });
  });

  describe('POST /api/pathfinding/find', () => {
    test('should find paths between stations successfully', async () => {
      const requestBody = {
        start_station: '佛山西',
        end_station: '肇庆'
      };

      const response = await request(app)
        .post('/api/pathfinding/find')
        .send(requestBody)
        .expect(200);

      expect(response.body.start_station).toBe('佛山西');
      expect(response.body.end_station).toBe('肇庆');
      expect(response.body.paths).toBeDefined();
      expect(response.body.summary).toBeDefined();
    });

    test('should validate required fields', async () => {
      // Missing start_station
      const response1 = await request(app)
        .post('/api/pathfinding/find')
        .send({ end_station: '肇庆' })
        .expect(400);

      expect(response1.body.error).toBe('Bad Request');
      expect(response1.body.field).toBe('start_station');

      // Missing end_station
      const response2 = await request(app)
        .post('/api/pathfinding/find')
        .send({ start_station: '佛山西' })
        .expect(400);

      expect(response2.body.error).toBe('Bad Request');
      expect(response2.body.field).toBe('end_station');
    });

    test('should validate station names are different', async () => {
      const response = await request(app)
        .post('/api/pathfinding/find')
        .send({
          start_station: '佛山西',
          end_station: '佛山西'
        })
        .expect(400);

      expect(response.body.error).toBe('Bad Request');
    });

    test('should validate station name length', async () => {
      const longName = 'a'.repeat(51); // Exceeds max length

      const response = await request(app)
        .post('/api/pathfinding/find')
        .send({
          start_station: longName,
          end_station: '肇庆'
        })
        .expect(400);

      expect(response.body.error).toBe('Bad Request');
      expect(response.body.field).toBe('start_station');
    });

    test('should validate optional parameters', async () => {
      // Invalid max_transfers
      const response1 = await request(app)
        .post('/api/pathfinding/find')
        .send({
          start_station: '佛山西',
          end_station: '肇庆',
          max_transfers: -1
        })
        .expect(400);

      expect(response1.body.error).toBe('Bad Request');
      expect(response1.body.field).toBe('max_transfers');

      // Invalid window_minutes
      const response2 = await request(app)
        .post('/api/pathfinding/find')
        .send({
          start_station: '佛山西',
          end_station: '肇庆',
          window_minutes: 500 // Exceeds max
        })
        .expect(400);

      expect(response2.body.error).toBe('Bad Request');
      expect(response2.body.field).toBe('window_minutes');
    });

    test('should handle service unavailable when data not loaded', async () => {
      // Mock data loading failure
      DataService.prototype.loadGraph = jest.fn().mockRejectedValue(new Error('File not found'));

      const response = await request(app)
        .post('/api/pathfinding/find')
        .send({
          start_station: '佛山西',
          end_station: '肇庆'
        })
        .expect(503);

      expect(response.body.error).toBe('Service Unavailable');
    });
  });

  describe('GET /api/pathfinding/stations', () => {
    test('should return list of stations', async () => {
      const response = await request(app)
        .get('/api/pathfinding/stations')
        .expect(200);

      expect(response.body.stations).toBeDefined();
      expect(Array.isArray(response.body.stations)).toBe(true);
      expect(response.body.total_count).toBeDefined();
    });

    test('should handle service unavailable', async () => {
      // This would require mocking the module-level variables
      // For now, just test the happy path
      const response = await request(app)
        .get('/api/pathfinding/stations')
        .expect(200);

      expect(response.body.stations).toBeDefined();
    });
  });

  describe('GET /api/pathfinding/status', () => {
    test('should return service status', async () => {
      const response = await request(app)
        .get('/api/pathfinding/status')
        .expect(200);

      expect(response.body.service).toBe('pathfinding');
      expect(response.body.status).toBe('healthy');
      expect(response.body.data_loaded).toBeDefined();
      expect(response.body.timestamp).toBeDefined();
    });
  });

  describe('POST /api/pathfinding/reload', () => {
    test('should reload data successfully', async () => {
      const response = await request(app)
        .post('/api/pathfinding/reload')
        .expect(200);

      expect(response.body.message).toBe('Data files reloaded successfully');
      expect(response.body.timestamp).toBeDefined();
    });

    test('should handle reload failure', async () => {
      // Mock reload failure
      DataService.prototype.loadGraph = jest.fn().mockRejectedValue(new Error('Reload failed'));

      const response = await request(app)
        .post('/api/pathfinding/reload')
        .expect(503);

      expect(response.body.error).toBe('Service Unavailable');
    });
  });

  describe('Error handling', () => {
    test('should handle 404 for unknown routes', async () => {
      const response = await request(app)
        .get('/unknown-route')
        .expect(404);

      expect(response.body.error).toBe('Not Found');
    });

    test('should handle invalid JSON', async () => {
      const response = await request(app)
        .post('/api/pathfinding/find')
        .set('Content-Type', 'application/json')
        .send('invalid json')
        .expect(400);

      expect(response.body.error).toBe('Invalid JSON');
    });
  });

  describe('Rate limiting', () => {
    test('should allow requests within limit', async () => {
      const requestBody = {
        start_station: '佛山西',
        end_station: '肇庆'
      };

      // Make a few requests within limit
      for (let i = 0; i < 5; i++) {
        await request(app)
          .post('/api/pathfinding/find')
          .send(requestBody)
          .expect(200);
      }
    });

    // Note: Testing rate limit exceeded would require mocking time or making many requests
    // This is generally not practical in unit tests
  });
});