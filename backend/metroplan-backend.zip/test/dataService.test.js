const DataService = require('../services/dataService');
const fs = require('fs').promises;
const path = require('path');

// Mock fs module
jest.mock('fs', () => ({
  promises: {
    readFile: jest.fn(),
    writeFile: jest.fn(),
    mkdir: jest.fn()
  }
}));

describe('DataService', () => {
  let dataService;

  beforeEach(() => {
    dataService = new DataService();
    jest.clearAllMocks();
  });

  describe('loadGraph', () => {
    test('should load graph data successfully', async () => {
      const mockGraphData = {
        nodes: [['StationA', 'Train1', '06:00']],
        edges: [{
          from: ['StationA', 'Train1', '06:00'],
          to: ['StationB', 'Train1', '06:30'],
          weight: 30,
          type: 'travel'
        }]
      };

      fs.readFile.mockResolvedValue(JSON.stringify(mockGraphData));

      const result = await dataService.loadGraph('test-graph.json');

      expect(fs.readFile).toHaveBeenCalledWith('test-graph.json', 'utf8');
      expect(result.nodes).toEqual(mockGraphData.nodes);
      expect(result.edges).toEqual(mockGraphData.edges);
    });

    test('should handle file not found error', async () => {
      fs.readFile.mockRejectedValue(new Error('ENOENT: no such file'));

      await expect(dataService.loadGraph('nonexistent.json')).rejects.toThrow('Failed to load graph data');
    });

    test('should handle invalid JSON', async () => {
      fs.readFile.mockResolvedValue('invalid json');

      await expect(dataService.loadGraph('invalid.json')).rejects.toThrow('Failed to load graph data');
    });
  });

  describe('loadSchedule', () => {
    test('should load schedule data successfully', async () => {
      const mockScheduleData = {
        train: [
          {
            id: 'Train1',
            start_station: 'StationA',
            end_station: 'StationB',
            is_fast: false,
            directionality: [1, 0, 0, 0]
          }
        ]
      };

      fs.readFile.mockResolvedValue(JSON.stringify(mockScheduleData));

      const result = await dataService.loadSchedule('test-schedule.json');

      expect(fs.readFile).toHaveBeenCalledWith('test-schedule.json', 'utf8');
      expect(result.train).toEqual(mockScheduleData.train);
    });
  });

  describe('extractTrainInfo', () => {
    test('should extract train information correctly', () => {
      const scheduleData = {
        train: [
          { id: 'Train1', is_fast: false, directionality: [1, 0] },
          { id: 'Train2', is_fast: true },
          { id: 'Train3' } // No is_fast property
        ]
      };

      const result = dataService.extractTrainInfo(scheduleData);

      expect(result['Train1']).toEqual({ is_fast: false, directionality: [1, 0] });
      expect(result['Train2']).toEqual({ is_fast: true, directionality: undefined });
      expect(result['Train3']).toEqual({ is_fast: false, directionality: undefined });
    });
  });

  describe('extractDirectionalityMap', () => {
    test('should extract directionality for trains with directionality arrays', () => {
      const scheduleData = {
        train: [
          { id: 'Train1', directionality: [1, 0, 0, 0] },
          { id: 'Train2', directionality: 'not-array' },
          { id: 'Train3' } // No directionality
        ]
      };

      const result = dataService.extractDirectionalityMap(scheduleData);

      expect(result['Train1']).toEqual([1, 0, 0, 0]);
      expect(result['Train2']).toBeUndefined();
      expect(result['Train3']).toBeUndefined();
    });
  });

  describe('buildAdjacencyList', () => {
    test('should build adjacency list correctly', () => {
      const nodes = [
        ['StationA', 'Train1', '06:00'],
        ['StationB', 'Train1', '06:30'],
        ['StationC', 'Train2', '07:00']
      ];

      const edges = [
        {
          from: ['StationA', 'Train1', '06:00'],
          to: ['StationB', 'Train1', '06:30'],
          weight: 30,
          type: 'travel'
        }
      ];

      const result = dataService.buildAdjacencyList(nodes, edges);

      expect(result[0]).toHaveLength(1);
      expect(result[0][0]).toEqual({
        to: 1,
        type: 'travel',
        duration: 30
      });
      expect(result[1]).toEqual([]);
      expect(result[2]).toEqual([]);
    });

    test('should skip edges with invalid duration', () => {
      const nodes = [['StationA', 'Train1', '06:00']];
      const edges = [
        {
          from: ['StationA', 'Train1', '06:00'],
          to: ['StationB', 'Train1', '06:30'],
          weight: -5,
          type: 'travel'
        }
      ];

      const result = dataService.buildAdjacencyList(nodes, edges);

      expect(result[0]).toEqual([]);
    });
  });

  describe('saveResults', () => {
    test('should save results to file successfully', async () => {
      const results = { test: 'data' };
      const filename = 'test-result.json';
      const outputDir = './test-results';

      fs.mkdir.mockResolvedValue();
      fs.writeFile.mockResolvedValue();

      const resultPath = await dataService.saveResults(results, filename, outputDir);

      expect(fs.mkdir).toHaveBeenCalledWith(outputDir, { recursive: true });
      expect(fs.writeFile).toHaveBeenCalledWith(
        path.join(outputDir, filename),
        JSON.stringify(results, null, 2),
        'utf8'
      );
      expect(resultPath).toBe(path.join(outputDir, filename));
    });
  });
});