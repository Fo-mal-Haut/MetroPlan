const PathfindingService = require('../services/pathfindingService');

describe('PathfindingService', () => {
  let pathfindingService;
  let mockNodes, mockAdjacency, mockTrainInfo, mockDirectionMap;

  beforeEach(() => {
    pathfindingService = new PathfindingService();

    // Mock data for testing
    mockNodes = [
      ['佛山西', 'C4781', '06:00'],    // 0
      ['狮山', 'C4781', '06:07'],     // 1
      ['狮山北', 'C4781', '06:12'],   // 2
      ['三水北', 'C4781', '06:21'],   // 3
      ['云东海', 'C4781', '06:29'],   // 4
      ['大旺', 'C4781', '06:35'],     // 5
      ['四会', 'C4781', '06:41'],     // 6
      ['狮山', 'D1234', '06:15'],     // 7 (same station, different train)
      ['三水北', 'D1234', '06:45']    // 8
    ];

    mockAdjacency = {
      0: [{ to: 1, type: 'travel', duration: 7 }],
      1: [{ to: 2, type: 'travel', duration: 5 }],
      2: [{ to: 3, type: 'travel', duration: 9 }],
      3: [{ to: 4, type: 'travel', duration: 8 }],
      4: [{ to: 5, type: 'travel', duration: 6 }],
      5: [{ to: 6, type: 'travel', duration: 6 }],
      6: [],
      7: [{ to: 8, type: 'travel', duration: 30 }],
      8: [],
      // Add transfer edge
      1: [{ to: 7, type: 'transfer', duration: 8 }, { to: 2, type: 'travel', duration: 5 }]
    };

    mockTrainInfo = {
      'C4781': { is_fast: false },
      'D1234': { is_fast: true }
    };

    mockDirectionMap = {
      'C4781': [1, 0, 0, 0],
      'D1234': [0, 1, 0, 0]
    };
  });

  describe('findAllPaths', () => {
    test('should find direct path between stations', () => {
      const paths = pathfindingService.findAllPaths(
        mockNodes,
        mockAdjacency,
        '佛山西',
        '大旺',
        mockTrainInfo,
        null,
        { maxTransfers: 2 }
      );

      expect(paths).toHaveLength(1);
      expect(paths[0].type).toBe('Direct');
      expect(paths[0].train_sequence).toEqual(['C4781']);
      expect(paths[0].transfer_count).toBe(0);
    });

    test('should find paths with transfers', () => {
      // Add a connection that enables transfer
      mockAdjacency[3].push({ to: 8, type: 'transfer', duration: 24 });

      const paths = pathfindingService.findAllPaths(
        mockNodes,
        mockAdjacency,
        '佛山西',
        '三水北',
        mockTrainInfo,
        null,
        { maxTransfers: 1 }
      );

      expect(paths.length).toBeGreaterThan(0);
      const transferPaths = paths.filter(p => p.transfer_count > 0);
      expect(transferPaths.length).toBeGreaterThan(0);
    });

    test('should respect max transfers limit', () => {
      const paths = pathfindingService.findAllPaths(
        mockNodes,
        mockAdjacency,
        '佛山西',
        '三水北',
        mockTrainInfo,
        null,
        { maxTransfers: 0 }
      );

      const transferPaths = paths.filter(p => p.transfer_count > 0);
      expect(transferPaths).toHaveLength(0);
    });

    test('should return empty array for invalid start station', () => {
      const paths = pathfindingService.findAllPaths(
        mockNodes,
        mockAdjacency,
        'NonExistentStation',
        '佛山西',
        mockTrainInfo,
        null,
        { maxTransfers: 2 }
      );

      expect(paths).toHaveLength(0);
    });

    test('should handle directionality validation', () => {
      // Add conflicting directionality
      mockDirectionMap['D1234'] = [-1, 0, 0, 0]; // Opposite direction

      const paths = pathfindingService.findAllPaths(
        mockNodes,
        mockAdjacency,
        '佛山西',
        '三水北',
        mockTrainInfo,
        mockDirectionMap,
        { maxTransfers: 1 }
      );

      // Should filter out paths with conflicting directions
      const transferPaths = paths.filter(p => p.transfer_count > 0);
      expect(transferPaths.every(p => {
        // Validate no conflicting directions in train sequence
        const seq = p.train_sequence;
        for (let i = 0; i < seq.length - 1; i++) {
          const a = mockDirectionMap[seq[i]];
          const b = mockDirectionMap[seq[i + 1]];
          if (a && b) {
            for (let j = 0; j < Math.min(a.length, b.length); j++) {
              if (a[j] !== 0 && b[j] !== 0 && a[j] === -b[j]) {
                return false; // Found conflicting direction
              }
            }
          }
        }
        return true;
      })).toBe(true);
    });
  });

  describe('mergePathsByTrainSequence', () => {
    test('should merge paths with identical train sequences', () => {
      const paths = [
        {
          train_sequence: ['C4781'],
          type: 'Direct',
          transfer_count: 0,
          departure_time: '06:00',
          arrival_time: '07:00',
          total_minutes: 60,
          transfer_details: []
        },
        {
          train_sequence: ['C4781'],
          type: 'Direct',
          transfer_count: 0,
          departure_time: '06:00',
          arrival_time: '07:00',
          total_minutes: 60,
          transfer_details: []
        },
        {
          train_sequence: ['C4781', 'D1234'],
          type: 'Transfer',
          transfer_count: 1,
          departure_time: '06:00',
          arrival_time: '08:00',
          total_minutes: 120,
          transfer_details: [
            { station: '狮山', arrival_time: '06:15', departure_time: '06:23', wait_minutes: 8 }
          ]
        }
      ];

      const merged = pathfindingService.mergePathsByTrainSequence(paths);

      expect(merged).toHaveLength(2); // Should merge the two identical paths
      expect(merged[0].train_sequence).toEqual(['C4781']);
      expect(merged[1].train_sequence).toEqual(['C4781', 'D1234']);
    });

    test('should aggregate transfer options for merged paths', () => {
      const paths = [
        {
          train_sequence: ['C4781', 'D1234'],
          type: 'Transfer',
          transfer_count: 1,
          departure_time: '06:00',
          arrival_time: '08:00',
          total_minutes: 120,
          transfer_details: [
            { station: '狮山', arrival_time: '06:15', departure_time: '06:23', wait_minutes: 8 }
          ]
        },
        {
          train_sequence: ['C4781', 'D1234'],
          type: 'Transfer',
          transfer_count: 1,
          departure_time: '06:00',
          arrival_time: '08:00',
          total_minutes: 120,
          transfer_details: [
            { station: '狮山北', arrival_time: '06:30', departure_time: '06:38', wait_minutes: 8 }
          ]
        }
      ];

      const merged = pathfindingService.mergePathsByTrainSequence(paths);

      expect(merged).toHaveLength(1);
      expect(merged[0].transfer_options).toHaveLength(1);
      expect(merged[0].transfer_options[0].options).toHaveLength(2);
      expect(merged[0].transfer_details).toHaveLength(1); // First option used as default
    });
  });

  describe('filterPathsByTimeWindow', () => {
    test('should filter paths by time window', () => {
      const paths = [
        { total_minutes: 60 },
        { total_minutes: 80 },
        { total_minutes: 150 },
        { total_minutes: 90 }
      ];

      const result = pathfindingService.filterPathsByTimeWindow(paths, 30);

      expect(result.paths).toHaveLength(3); // 60, 80, 90 are within 30 minutes of 60 (fastest)
      expect(result.fastestMinutes).toBe(60);
    });

    test('should handle empty paths array', () => {
      const result = pathfindingService.filterPathsByTimeWindow([], 60);

      expect(result.paths).toHaveLength(0);
      expect(result.fastestMinutes).toBe(0);
    });
  });

  describe('summarizePath', () => {
    test('should create correct path summary', () => {
      const edgeHistory = [
        { from: 0, to: 1, type: 'travel', duration: 7 },
        { from: 1, to: 7, type: 'transfer', duration: 8 },
        { from: 7, to: 8, type: 'travel', duration: 30 }
      ];

      const summary = pathfindingService.summarizePath(
        mockNodes,
        edgeHistory,
        ['C4781', 'D1234'],
        360, // 06:00
        405, // 06:45
        mockTrainInfo
      );

      expect(summary.type).toBe('Transfer');
      expect(summary.train_sequence).toEqual(['C4781', 'D1234']);
      expect(summary.transfer_count).toBe(1);
      expect(summary.transfer_details).toHaveLength(1);
      expect(summary.transfer_details[0].station).toBe('狮山');
      expect(summary.is_fast).toBe(true); // D1234 is fast
    });

    test('should handle direct path correctly', () => {
      const edgeHistory = [
        { from: 0, to: 1, type: 'travel', duration: 7 }
      ];

      const summary = pathfindingService.summarizePath(
        mockNodes,
        edgeHistory,
        ['C4781'],
        360, // 06:00
        367, // 06:07
        mockTrainInfo
      );

      expect(summary.type).toBe('Direct');
      expect(summary.transfer_count).toBe(0);
      expect(summary.transfer_details).toHaveLength(0);
      expect(summary.is_fast).toBe(false); // C4781 is not fast
    });
  });

  describe('getStats', () => {
    test('should return current statistics', () => {
      pathfindingService.stats.skipped_same_station_transfers = 5;

      const stats = pathfindingService.getStats();

      expect(stats.skipped_same_station_transfers).toBe(5);
    });
  });
});