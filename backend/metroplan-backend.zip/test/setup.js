// Test setup file
require('dotenv').config({ path: '.env.test' });

// Set test environment variables
process.env.NODE_ENV = 'test';
process.env.PORT = '3001'; // Use different port for testing
process.env.GRAPH_FILE_PATH = './test/fixtures/test_graph.json';
process.env.SCHEDULE_FILE_PATH = './test/fixtures/test_schedule.json';
process.env.RESULTS_DIR = './test/results';

// Mock console methods to reduce noise in tests
const originalConsole = global.console;

beforeAll(() => {
  global.console = {
    ...originalConsole,
    log: jest.fn(),
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
  };
});

afterAll(() => {
  global.console = originalConsole;
});

// Increase timeout for async operations
jest.setTimeout(10000);