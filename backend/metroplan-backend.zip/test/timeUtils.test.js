const { parseTime, toTime, timeDifference, formatDuration } = require('../utils/timeUtils');

describe('Time Utils', () => {
  describe('parseTime', () => {
    test('should parse normal time correctly', () => {
      expect(parseTime('06:30')).toBe(390); // 6*60 + 30
      expect(parseTime('23:59')).toBe(1439); // 23*60 + 59
    });

    test('should handle midnight as next day', () => {
      expect(parseTime('00:00')).toBe(1440); // Next day
    });

    test('should handle empty or invalid input', () => {
      expect(parseTime('')).toBe(0);
      expect(parseTime(null)).toBe(0);
      expect(parseTime(undefined)).toBe(0);
    });
  });

  describe('toTime', () => {
    test('should convert minutes to time string correctly', () => {
      expect(toTime(390)).toBe('06:30');
      expect(toTime(0)).toBe('00:00');
      expect(toTime(1439)).toBe('23:59');
    });

    test('should handle day wrap around', () => {
      expect(toTime(1440)).toBe('00:00'); // Next day
      expect(toTime(1500)).toBe('01:00'); // 1500 % 1440 = 60
    });
  });

  describe('timeDifference', () => {
    test('should calculate time difference correctly', () => {
      expect(timeDifference(360, 420)).toBe(60); // 06:00 to 07:00
      expect(timeDifference(1380, 60)).toBe(60); // 23:00 to 01:00 next day
    });

    test('should handle same time', () => {
      expect(timeDifference(360, 360)).toBe(0);
    });
  });

  describe('formatDuration', () => {
    test('should format duration correctly', () => {
      expect(formatDuration(67)).toBe('1h 7m');
      expect(formatDuration(120)).toBe('2h 0m');
      expect(formatDuration(45)).toBe('0h 45m');
      expect(formatDuration(0)).toBe('0h 0m');
    });
  });
});